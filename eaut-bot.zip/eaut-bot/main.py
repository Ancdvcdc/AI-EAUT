import time, sqlite3, hashlib, secrets
import numpy as np, httpx
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

OLLAMA = "http://localhost:11434"
EMB_MODEL = "bge-m3"
DB = "data.db"
DEFAULTS = {
    "bot_name": "Trâu Thông Thái",
    "threshold": "0.55",
    "use_llm": "1",
    "llm_model": "qwen2.5:3b",
    "max_len": "300",
    "rate_per_min": "10",
    "blocked": "",
    "fallback": "Mình chỉ hỗ trợ các câu hỏi về tuyển sinh và sinh viên. Bạn vui lòng liên hệ phòng Tuyển sinh để được hỗ trợ thêm nhé!",
    "greeting": "Xin chào! Mình là trợ lý tuyển sinh. Bạn muốn hỏi gì nào?",
}
app = FastAPI()
hits = {}


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def hpw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200000).hex()


def init():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY, pw TEXT, salt TEXT, role TEXT);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, username TEXT, role TEXT);
    CREATE TABLE IF NOT EXISTS qa(id INTEGER PRIMARY KEY, category TEXT, question TEXT, answer TEXT, emb BLOB);
    CREATE TABLE IF NOT EXISTS unanswered(id INTEGER PRIMARY KEY, question TEXT, ts INTEGER);
    CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
    """)
    for k, v in DEFAULTS.items():
        c.execute("INSERT OR IGNORE INTO settings VALUES(?,?)", (k, v))
    if not c.execute("SELECT 1 FROM users").fetchone():
        s = secrets.token_hex(16)
        c.execute("INSERT INTO users VALUES(?,?,?,?)", ("admin", hpw("admin123", s), s, "admin"))
        print(">>> Tài khoản mặc định: admin / admin123 (hãy đổi mật khẩu ngay!)")
    c.commit()
    c.close()


init()


def cfg():
    c = db()
    d = {r["k"]: r["v"] for r in c.execute("SELECT * FROM settings")}
    c.close()
    return d


def embed(text):
    r = httpx.post(f"{OLLAMA}/api/embed", json={"model": EMB_MODEL, "input": text}, timeout=60)
    v = np.array(r.json()["embeddings"][0], dtype=np.float32)
    return v / (np.linalg.norm(v) + 1e-9)


_idx = {"key": None, "m": None, "rows": []}


def get_index():
    c = db()
    key = tuple(c.execute("SELECT COUNT(*), COALESCE(MAX(id),0) FROM qa WHERE emb IS NOT NULL").fetchone())
    if key != _idx["key"]:
        rows = c.execute("SELECT question, answer, emb FROM qa WHERE emb IS NOT NULL").fetchall()
        _idx["m"] = np.vstack([np.frombuffer(r["emb"], dtype=np.float32) for r in rows]) if rows else None
        _idx["rows"] = [(r["question"], r["answer"]) for r in rows]
        _idx["key"] = key
    c.close()
    return _idx


def need(role):
    def dep(authorization: str = Header(default="")):
        c = db()
        s = c.execute("SELECT * FROM sessions WHERE token=?", (authorization.replace("Bearer ", ""),)).fetchone()
        c.close()
        if not s or (role == "admin" and s["role"] != "admin"):
            raise HTTPException(403, "Không đủ quyền")
        return s
    return dep


# ---------- Chat (ai cũng dùng được) ----------
class Chat(BaseModel):
    message: str


@app.get("/api/public")
def public():
    c = cfg()
    return {"bot_name": c["bot_name"], "greeting": c["greeting"]}


@app.post("/api/chat")
def chat(body: Chat, req: Request):
    c = cfg()
    q = body.message.strip()
    ip = req.client.host
    now = time.time()
    hits[ip] = [t for t in hits.get(ip, []) if now - t < 60]
    if len(hits[ip]) >= int(c["rate_per_min"]):
        return {"answer": "Bạn hỏi nhanh quá, vui lòng đợi một chút nhé!"}
    hits[ip].append(now)
    if not q or len(q) > int(c["max_len"]):
        return {"answer": f"Câu hỏi cần từ 1 đến {c['max_len']} ký tự."}
    if any(w.strip() and w.strip().lower() in q.lower() for w in c["blocked"].split(",")):
        return {"answer": c["fallback"]}
    ix = get_index()
    best, seen = [], set()
    if ix["m"] is not None:
        sc = ix["m"] @ embed(q)
        for i in np.argsort(-sc)[:40]:
            qq, aa = ix["rows"][i]
            if aa not in seen:
                seen.add(aa)
                best.append((float(sc[i]), qq, aa))
            if len(best) == 3:
                break
    if not best or best[0][0] < float(c["threshold"]):
        db_ = db()
        db_.execute("INSERT INTO unanswered(question, ts) VALUES(?,?)", (q, int(now)))
        db_.commit()
        db_.close()
        return {"answer": c["fallback"]}
    if c["use_llm"] != "1":
        return {"answer": best[0][2]}
    ctx = "\n\n".join(f"Hỏi: {qq}\nĐáp: {aa}" for s, qq, aa in best if s >= float(c["threshold"]) - 0.1)
    sys = ("Bạn là trợ lý tuyển sinh và hỗ trợ sinh viên. Chỉ trả lời bằng tiếng Việt, ngắn gọn, thân thiện, "
           "DỰA TRÊN thông tin được cung cấp. Không bịa số liệu. Nếu thông tin không đủ, hãy nói chưa có và gợi ý liên hệ nhà trường.")
    try:
        r = httpx.post(f"{OLLAMA}/api/chat", timeout=120, json={
            "model": c["llm_model"], "stream": False, "options": {"temperature": 0.2},
            "messages": [{"role": "system", "content": sys},
                         {"role": "user", "content": f"Thông tin:\n{ctx}\n\nCâu hỏi: {q}"}]})
        return {"answer": r.json()["message"]["content"]}
    except Exception:
        return {"answer": best[0][2]}


# ---------- Đăng nhập ----------
class Login(BaseModel):
    username: str
    password: str


@app.post("/api/login")
def login(b: Login):
    c = db()
    u = c.execute("SELECT * FROM users WHERE username=?", (b.username,)).fetchone()
    if not u or hpw(b.password, u["salt"]) != u["pw"]:
        raise HTTPException(401, "Sai tài khoản hoặc mật khẩu")
    t = secrets.token_hex(24)
    c.execute("INSERT INTO sessions VALUES(?,?,?)", (t, u["username"], u["role"]))
    c.commit()
    return {"token": t, "role": u["role"], "username": u["username"]}


# ---------- Q&A (biên tập viên + quản trị) ----------
class QA(BaseModel):
    category: str = ""
    question: str
    answer: str


@app.get("/api/qa")
def qa_list(q: str = "", page: int = 0, a=__import__("fastapi").Depends(need("editor"))):
    c = db()
    w, p = ("WHERE question LIKE ? OR answer LIKE ? OR category LIKE ?", [f"%{q}%"] * 3) if q else ("", [])
    total = c.execute(f"SELECT COUNT(*) FROM qa {w}", p).fetchone()[0]
    rows = c.execute(f"SELECT id,category,question,answer FROM qa {w} ORDER BY id DESC LIMIT 30 OFFSET ?", p + [page * 30]).fetchall()
    return {"total": total, "items": [dict(r) for r in rows]}


@app.post("/api/qa")
def qa_add(b: QA, a=__import__("fastapi").Depends(need("editor"))):
    c = db()
    c.execute("INSERT INTO qa(category,question,answer,emb) VALUES(?,?,?,?)",
              (b.category, b.question, b.answer, embed(b.question).tobytes()))
    c.commit()
    return {"ok": 1}


@app.put("/api/qa/{i}")
def qa_edit(i: int, b: QA, a=__import__("fastapi").Depends(need("editor"))):
    c = db()
    c.execute("UPDATE qa SET category=?,question=?,answer=?,emb=? WHERE id=?",
              (b.category, b.question, b.answer, embed(b.question).tobytes(), i))
    c.commit()
    _idx["key"] = None
    return {"ok": 1}


@app.delete("/api/qa/{i}")
def qa_del(i: int, a=__import__("fastapi").Depends(need("editor"))):
    c = db()
    c.execute("DELETE FROM qa WHERE id=?", (i,))
    c.commit()
    return {"ok": 1}


@app.get("/api/unanswered")
def un_list(a=__import__("fastapi").Depends(need("editor"))):
    return [dict(r) for r in db().execute("SELECT * FROM unanswered ORDER BY id DESC LIMIT 200")]


@app.delete("/api/unanswered/{i}")
def un_del(i: int, a=__import__("fastapi").Depends(need("editor"))):
    c = db()
    c.execute("DELETE FROM unanswered WHERE id=?", (i,))
    c.commit()
    return {"ok": 1}


# ---------- Chỉ quản trị viên ----------
class NewUser(BaseModel):
    username: str
    password: str
    role: str = "editor"


@app.get("/api/users")
def users(a=__import__("fastapi").Depends(need("admin"))):
    return [dict(r) for r in db().execute("SELECT username, role FROM users")]


@app.post("/api/users")
def user_add(b: NewUser, a=__import__("fastapi").Depends(need("admin"))):
    s = secrets.token_hex(16)
    c = db()
    c.execute("INSERT OR REPLACE INTO users VALUES(?,?,?,?)", (b.username, hpw(b.password, s), s, b.role))
    c.commit()
    return {"ok": 1}


@app.delete("/api/users/{u}")
def user_del(u: str, a=__import__("fastapi").Depends(need("admin"))):
    if u == a["username"]:
        raise HTTPException(400, "Không thể tự xóa mình")
    c = db()
    c.execute("DELETE FROM users WHERE username=?", (u,))
    c.commit()
    return {"ok": 1}


@app.get("/api/settings")
def get_settings(a=__import__("fastapi").Depends(need("admin"))):
    return cfg()


@app.put("/api/settings")
def set_settings(b: dict, a=__import__("fastapi").Depends(need("admin"))):
    c = db()
    for k, v in b.items():
        if k in DEFAULTS:
            c.execute("REPLACE INTO settings VALUES(?,?)", (k, str(v)))
    c.commit()
    return {"ok": 1}


@app.get("/admin")
def admin_page():
    return FileResponse("static/admin.html")


@app.get("/")
def index():
    return FileResponse("static/index.html")


app.mount("/static", StaticFiles(directory="static"), name="static")
