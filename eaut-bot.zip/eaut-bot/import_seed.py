"""Nhập seed.jsonl vào data.db (cần Ollama đang chạy + đã pull bge-m3). Hãy TẮT server trước khi chạy."""
import json, sys, time
import numpy as np, httpx
from main import db, OLLAMA, EMB_MODEL

TAG = "[mẫu] "
rows = [json.loads(l) for l in open("seed.jsonl", encoding="utf-8")]
c = db()
c.execute("DELETE FROM qa WHERE category LIKE ?", (TAG + "%",))
c.commit()
t0, B = time.time(), 64
for i in range(0, len(rows), B):
    chunk = rows[i:i + B]
    r = httpx.post(f"{OLLAMA}/api/embed", json={"model": EMB_MODEL, "input": [x["question"] for x in chunk]}, timeout=300)
    embs = np.array(r.json()["embeddings"], dtype=np.float32)
    embs /= np.linalg.norm(embs, axis=1, keepdims=True) + 1e-9
    c.executemany("INSERT INTO qa(category,question,answer,emb) VALUES(?,?,?,?)",
                  [(TAG + x["category"], x["question"], x["answer"], e.tobytes()) for x, e in zip(chunk, embs)])
    c.commit()
    done = i + len(chunk)
    print(f"\r{done}/{len(rows)}  ({done / (time.time() - t0):.0f} câu/giây)", end="", flush=True)
print("\nXong! Khởi động lại server. Dữ liệu mẫu có nhãn danh mục bắt đầu bằng '[mẫu]'.")
