"""Sinh bộ dữ liệu mẫu seed.jsonl từ tài liệu EAUT. Chạy: python gen_data.py [số_câu]"""
import json, random, unicodedata, sys, math
random.seed(7)
TARGET = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
FACTS = []
def F(cat, topics, ans): FACTS.append((cat, topics, ans))
HL = "0243.555.2008"
OLD = f" (Thông tin theo thông báo năm 2023, bạn nên liên hệ phòng Tuyển sinh {HL} để xác nhận lại.)"

# ---------- Tổ hợp ----------
TH = {"A00":"Toán, Vật lý, Hóa học","A01":"Toán, Vật lý, Tiếng Anh","A02":"Toán, Vật lý, Sinh học","A03":"Toán, Vật lý, Lịch sử",
"A05":"Toán, Hóa học, Lịch sử","A06":"Toán, Hóa học, Địa lí","A07":"Toán, Lịch sử, Địa lí","A08":"Toán, Lịch sử, Giáo dục kinh tế và pháp luật",
"A09":"Toán, Địa lí, Giáo dục kinh tế và pháp luật","A10":"Toán, Vật lý, Giáo dục kinh tế và pháp luật","A11":"Toán, Hóa học, Giáo dục kinh tế và pháp luật",
"B00":"Toán, Hóa học, Sinh học","B01":"Toán, Sinh học, Lịch sử","B02":"Toán, Sinh học, Địa lí","B03":"Toán, Sinh học, Ngữ văn",
"B04":"Toán, Sinh học, Giáo dục kinh tế và pháp luật","B08":"Toán, Sinh học, Tiếng Anh","C00":"Ngữ văn, Lịch sử, Địa lí",
"C01":"Ngữ văn, Toán, Vật lý","C02":"Toán, Ngữ văn, Hóa học","C03":"Toán, Ngữ văn, Lịch sử","C04":"Toán, Ngữ văn, Địa lí",
"C14":"Toán, Ngữ văn, Giáo dục kinh tế và pháp luật","C19":"Ngữ văn, Lịch sử, Giáo dục kinh tế và pháp luật",
"C20":"Ngữ văn, Địa lí, Giáo dục kinh tế và pháp luật","D01":"Toán, Ngữ văn, Tiếng Anh","D04":"Toán, Ngữ văn, Tiếng Trung",
"D06":"Toán, Ngữ văn, Tiếng Nhật","D07":"Toán, Hóa học, Tiếng Anh","D08":"Toán, Sinh học, Tiếng Anh","D10":"Toán, Tiếng Anh, Địa lí",
"D14":"Ngữ văn, Lịch sử, Tiếng Anh","D15":"Ngữ văn, Địa lí, Tiếng Anh","D66":"Ngữ văn, Giáo dục kinh tế và pháp luật, Tiếng Anh",
"D78":"Ngữ văn, Khoa học xã hội, Tiếng Anh","D83":"Ngữ văn, Khoa học xã hội, Tiếng Trung"}
B1 = "A00 A01 A02 A03 A05 A06 A07 A08 A09 A10 A11 C01 C02 C03 C14 D01 D07".split()
BLK = {1: B1, 2: B1 + ["D10"], 3: "C00 C01 C02 C03 C04 C14 C19 C20 D01 D14 D15 D04 D06 D78 D83 D66".split(),
       4: "A00 A02 A03 B00 B01 B02 B03 B04 B08 D07".split()}
GRP = {1: ("kỹ thuật", "14.000.000đ – 20.000.000đ/kỳ"), 2: ("kinh tế – xã hội", "16.000.000đ – 21.500.000đ/kỳ"),
       3: ("kinh tế – xã hội", "16.000.000đ – 21.500.000đ/kỳ"), 4: ("sức khỏe", "18.000.000đ – 24.000.000đ/kỳ")}
def combos(codes): return "; ".join(f"{c} ({TH[c]})" for c in codes)
for c, m in TH.items():
    F("Tổ hợp xét tuyển", [f"tổ hợp {c} gồm những môn nào", f"khối {c} thi môn gì", f"{c} là tổ hợp môn nào"], f"Tổ hợp {c} gồm các môn: {m}.")

# ---------- Ngành ----------
N = [("Công nghệ thông tin","7480201",1,None),("Thiết kế đồ họa số","7480201",1,"Công nghệ thông tin"),
("Trí tuệ nhân tạo ứng dụng","7480201",1,"Công nghệ thông tin"),("Công nghệ kỹ thuật điện – điện tử","7510301",1,None),
("Công nghệ kỹ thuật bán dẫn","7510301",1,"Công nghệ kỹ thuật điện – điện tử"),("Công nghệ kỹ thuật điều khiển và tự động hóa","7510303",1,None),
("Công nghệ kỹ thuật ô tô","7510205",1,None),("Công nghệ kỹ thuật nhiệt (Nhiệt – Điện lạnh)","7510206",1,None),
("Điện lạnh và điều hòa không khí","7510206",1,"Công nghệ kỹ thuật nhiệt"),("Công nghệ kỹ thuật môi trường (chuyên ngành Công nghệ nước)","7510406",1,None),
("Công nghệ chế tạo máy","7510202",1,None),("Cơ điện tử","7510202",1,"Công nghệ chế tạo máy"),("Kỹ thuật xây dựng","7580201",1,None),
("Kiến trúc","7580101",1,None),("Kiến trúc nội thất","7580101",1,"Kiến trúc"),("Công nghệ thực phẩm","7540101",1,None),
("Kế toán","7340301",2,None),("Kế toán định hướng ACCA","7340301",2,"Kế toán"),("Tài chính ngân hàng","7340201",2,None),
("Công nghệ tài chính","7340205",2,None),("Quản trị kinh doanh","7340101",2,None),("Quản trị kinh doanh thời trang","7340101",2,"Quản trị kinh doanh"),
("Marketing","7340115",2,None),("Quản trị nhân lực","7340404",2,None),("Logistics và quản lý chuỗi cung ứng","7510605",2,None),
("Luật","7380101",2,None),("Ngôn ngữ Anh","7220201",3,None),("Ngôn ngữ Trung Quốc","7220204",3,None),("Ngôn ngữ Hàn Quốc","7220210",3,None),
("Ngôn ngữ Nhật","7220209",3,None),("Quản trị dịch vụ du lịch và lữ hành","7810103",3,None),("Quản trị khách sạn","7810201",3,None),
("Dược học","7720201",4,None),("Điều dưỡng","7720301",4,None)]
AL = {"Công nghệ thông tin":["CNTT","IT"],"Quản trị kinh doanh":["QTKD"],"Tài chính ngân hàng":["TCNH"],"Công nghệ kỹ thuật ô tô":["ô tô"],
"Ngôn ngữ Anh":["tiếng Anh"],"Ngôn ngữ Trung Quốc":["tiếng Trung"],"Ngôn ngữ Hàn Quốc":["tiếng Hàn"],"Ngôn ngữ Nhật":["tiếng Nhật"],
"Thiết kế đồ họa số":["đồ họa"],"Trí tuệ nhân tạo ứng dụng":["AI","trí tuệ nhân tạo"],"Dược học":["dược"],"Kế toán định hướng ACCA":["ACCA"],
"Logistics và quản lý chuỗi cung ứng":["logistics"],"Công nghệ kỹ thuật điều khiển và tự động hóa":["tự động hóa"],"Quản trị khách sạn":["khách sạn"],
"Quản trị dịch vụ du lịch và lữ hành":["du lịch lữ hành"],"Công nghệ thực phẩm":["thực phẩm"],"Kỹ thuật xây dựng":["xây dựng"],"Cơ điện tử":["cơ điện tử"]}
PAT = {"code": ["mã ngành {n} là gì","ngành {n} mã bao nhiêu","mã xét tuyển ngành {n}"],
"combo": ["ngành {n} xét tuyển những tổ hợp nào","thi khối nào để vào ngành {n}","học {n} thi tổ hợp môn gì"],
"fee": ["học phí ngành {n} bao nhiêu","học {n} tốn bao nhiêu tiền một kỳ","mức học phí của ngành {n}"],
"info": ["trường có ngành {n} không","ngành {n} có đào tạo ở EAUT không","giới thiệu ngành {n}"]}
def tp(key, names): return [PAT[key][0].format(n=names[0])] + [p.format(n=names[0]) for p in PAT[key][1:]] + [PAT[key][0].format(n=a) for a in names[1:]]
for name, code, blk, parent in N:
    grp, fee = GRP[blk]; names = [name] + AL.get(name, [])
    what = f"Chuyên ngành {name} thuộc ngành {parent}" if parent else f"Ngành {name}"
    extra = ""
    if name == "Công nghệ thực phẩm": extra = " Ngành này xét thêm tổ hợp B00 (Toán, Hóa học, Sinh học) và D08 (Toán, Sinh học, Tiếng Anh)."
    if name in ("Thiết kế đồ họa số","Kiến trúc","Kiến trúc nội thất"): extra = " Ngành này xét tuyển thêm khối H, V và sử dụng kết quả các bài thi năng khiếu mà thí sinh đã tham gia."
    if blk == 4: extra = " Lưu ý: Phương thức 3 (xét tuyển kết hợp) không áp dụng cho khối ngành sức khỏe."
    F("Ngành đào tạo", tp("code", names), f"{what} có mã ngành {code}.")
    F("Ngành đào tạo", tp("combo", names), f"{what} (mã {code}) xét tuyển các tổ hợp: {combos(BLK[blk])}.{extra}")
    F("Học phí & lệ phí", tp("fee", names), f"Học phí dự kiến năm học 2026 – 2027 của khối ngành {grp} (gồm {name}) là {fee}. Nhà trường không thu thêm khoản nào ngoài các khoản đã thông báo. Hotline: {HL}.")
    F("Ngành đào tạo", tp("info", names), f"Có. Năm 2026 Trường tuyển sinh {what[0].lower()+what[1:]} (mã ngành {code}), thuộc khối ngành {grp}. Học phí dự kiến {fee}.{extra} Chi tiết liên hệ hotline {HL}.")
allN = "; ".join(f"{n} ({c})" for n, c, b, p in N)
F("Ngành đào tạo", ["trường có những ngành nào","danh sách các ngành đào tạo đại học chính quy","năm 2026 trường tuyển sinh những ngành gì","các ngành học ở EAUT"], f"Năm 2026 Trường tuyển sinh 34 ngành, chuyên ngành đại học chính quy: {allN}.")
for g, k in (("kỹ thuật",1),("kinh tế – xã hội",2),("sức khỏe",4)):
    ns = "; ".join(n for n, c, b, p in N if (b in (2,3) if k == 2 else b == k))
    F("Ngành đào tạo", [f"khối ngành {g} gồm những ngành nào", f"các ngành thuộc khối {g}"], f"Các ngành/chuyên ngành thuộc khối ngành {g}: {ns}. Học phí dự kiến {GRP[k][1]}.")

# ---------- Giới thiệu ----------
F("Giới thiệu", ["trường được thành lập khi nào","ngày thành lập Trường Đại học Công nghệ Đông Á","quyết định thành lập trường là gì"], "Trường được Thủ tướng Chính phủ cho phép thành lập ngày 09/12/2008 theo Quyết định số 1777/QĐ-TTg. Trường là đại học đa ngành nằm trong hệ thống giáo dục quốc dân.")
F("Giới thiệu", ["trường đào tạo những trình độ nào","các hình thức đào tạo của trường","trường có đào tạo liên thông và vừa làm vừa học không"], "Trường đào tạo trình độ Đại học và Sau đại học, với các hình thức: chính quy, liên thông, vừa làm vừa học.")
F("Giới thiệu", ["trường có bao nhiêu ngành đào tạo","trường có những ngành sau đại học nào"], "Trường đang đào tạo 34 ngành, chuyên ngành đại học chính quy và 05 ngành sau đại học: Kế toán, Quản trị kinh doanh, Điện – điện tử, Công nghệ thông tin, Du lịch.")
F("Giới thiệu", ["mã trường Đại học Công nghệ Đông Á là gì","mã trường EAUT là gì","mã trường khi đăng ký nguyện vọng"], "Mã trường Đại học Công nghệ Đông Á là DDA.")
F("Sứ mệnh – Tầm nhìn", ["sứ mạng của trường là gì","sứ mệnh của Đại học Công nghệ Đông Á"], "Sứ mạng: đào tạo nguồn nhân lực chất lượng cao, ứng dụng thực tiễn, có năng lực hội nhập quốc tế, đáp ứng nhu cầu phát triển kinh tế – xã hội của đất nước và khu vực, thúc đẩy nghiên cứu, đổi mới sáng tạo và chuyển giao công nghệ.")
F("Sứ mệnh – Tầm nhìn", ["mục tiêu chiến lược của trường","mục tiêu của trường là gì"], "Mục tiêu chiến lược: xây dựng trường thành đại học đa ngành có uy tín trong hệ thống giáo dục đại học; đào tạo nguồn nhân lực phát triển toàn diện về kiến thức chuyên môn và kỹ năng nghề nghiệp, phục vụ công nghiệp hóa, hiện đại hóa và hội nhập quốc tế.")
F("Sứ mệnh – Tầm nhìn", ["tầm nhìn của trường là gì","trường hướng tới trở thành trường như thế nào"], "Tầm nhìn: trở thành trường đại học ứng dụng hàng đầu khu vực, tiên phong đào tạo kỹ thuật – công nghệ – kinh tế số ứng dụng, gắn kết chặt chẽ với doanh nghiệp và đạt chuẩn quốc tế ở một số chương trình đào tạo.")
F("Sứ mệnh – Tầm nhìn", ["giá trị cốt lõi của trường","trường theo đuổi những giá trị nào"], "Giá trị cốt lõi: Học đi đôi với hành; Chất lượng và hiệu quả; Đổi mới sáng tạo; Trung thực và trách nhiệm.")
F("Sứ mệnh – Tầm nhìn", ["triết lý giáo dục của trường","triết lý đào tạo của EAUT là gì"], "Triết lý giáo dục: Học để biết, để làm và để thay đổi.")
F("Giới thiệu", ["tập đoàn nào đầu tư vào trường","POLYCO có liên quan gì đến trường","trường có quan hệ với tập đoàn POLYCO không"], "Năm 2015, Trường tiếp nhận đầu tư trực tiếp của Tập đoàn POLYCO – tập đoàn hàng đầu Việt Nam về nghiên cứu, thiết kế, chế tạo và chuyển giao công nghệ trong ngành công nghệ thực phẩm (rượu, bia, nước giải khát, sữa, hóa chất, dược phẩm).")
F("Giới thiệu", ["đối tác chiến lược của trường là những ai","trường hợp tác với doanh nghiệp nào","đối tác doanh nghiệp của EAUT"], "Đối tác của Trường và POLYCO gồm: SABECO, HABECO, Vinamilk, Công ty ĐTPT XNK và thương mại Việt Hà, KRONES, KHS, KIESELMANN, SIEMENS, ROCKWELL, MAYEKAWA… và nhiều tập đoàn trong và ngoài nước.")
F("Giới thiệu", ["trường đào tạo theo định hướng nào","sinh viên có cơ hội việc làm và thực tập không","trường có gắn với thực tiễn không"], "Trường đào tạo theo định hướng ứng dụng và cam kết là cầu nối giúp sinh viên có nhiều cơ hội việc làm và trải nghiệm thực tiễn.")
F("Giới thiệu", ["trường muốn đào tạo thế hệ trẻ như thế nào","phương châm Sáng tạo Bản lĩnh Chủ động"], "Trường tiên phong đào tạo thế hệ trẻ Việt Nam trở thành công dân toàn cầu “Sáng tạo – Bản lĩnh – Chủ động”, nhanh nhạy với thời cơ, đương đầu thách thức, khởi nghiệp thành công trong thời kỳ hội nhập.")
F("Định hướng phát triển", ["định hướng phát triển của trường","trường phát triển theo hướng nào"], "Định hướng cơ bản: đổi mới quản trị đại học; hội nhập quốc tế; chú trọng chất lượng; phát triển chương trình đào tạo ngành rộng gắn thực hành nghề nghiệp; gắn kết nghiên cứu với đào tạo, khởi nghiệp và chuyển giao tri thức.")
F("Định hướng phát triển", ["trường có chú trọng người học không","quản trị đại học của trường theo mô hình nào"], "Trường đổi mới quản trị theo mô hình tiên tiến, tự chủ đi đôi với trách nhiệm xã hội, coi người học là chủ thể, trung tâm của mọi hoạt động; tôn trọng cơ chế thị trường nhưng không thương mại hóa.")
F("Định hướng phát triển", ["trường có hội nhập quốc tế không","trường áp dụng tiêu chuẩn chất lượng nào"], "Trường phát triển theo định hướng hội nhập quốc tế, áp dụng tiêu chuẩn chất lượng khu vực và quốc tế, tiếp thu chọn lọc mô hình của các đại học danh tiếng thế giới.")
F("Định hướng phát triển", ["trường ưu tiên lĩnh vực nghiên cứu nào","trường có chú trọng cách mạng công nghiệp 4.0 không"], "Trường tập trung phát huy thế mạnh cốt lõi, ưu tiên các lĩnh vực khoa học công nghệ then chốt đối với kinh tế tri thức và cách mạng công nghiệp 4.0, tăng quy mô đào tạo ở mức hợp lý.")
F("Định hướng phát triển", ["chương trình đào tạo của trường có đặc điểm gì","phương thức tổ chức đào tạo của trường"], "Chương trình đào tạo theo ngành rộng, trang bị kiến thức nền tảng vững chắc, chú trọng năng lực thực hành và khả năng thích ứng môi trường quốc tế; ứng dụng công nghệ giáo dục mới, thúc đẩy tự học qua nghiên cứu, sáng tạo và trải nghiệm.")
F("Định hướng phát triển", ["trường có nghiên cứu khoa học và khởi nghiệp không","hoạt động nghiên cứu của trường"], "Trường phát triển hài hòa nghiên cứu cơ bản, nghiên cứu ứng dụng và nghiên cứu triển khai; gắn nghiên cứu với đào tạo, sáng tạo và khởi nghiệp, thúc đẩy chuyển giao tri thức và thương mại hóa sản phẩm.")
F("Giới thiệu", ["linh vật của trường là con gì","mascot EAUT là gì","ý nghĩa linh vật của Đại học Công nghệ Đông Á"], "Linh vật của Trường là hình ảnh nhân cách hóa từ con Trâu – con vật rất quen thuộc trong đời sống, văn học, nghệ thuật Việt Nam. Linh vật được thiết kế gắn với yếu tố công nghệ – mục tiêu hướng tới và phát triển của xã hội hiện nay.")
F("Chào hỏi", ["xin chào","chào bạn","hello","hi bạn"], "Xin chào! Mình là trợ lý tuyển sinh. Bạn muốn hỏi về ngành học, học phí, cách xét tuyển hay thủ tục nhập học?")
F("Chào hỏi", ["bạn là ai","bạn tên gì","bạn là chatbot à"], "Mình là trợ lý ảo hỗ trợ giải đáp tuyển sinh và thông tin sinh viên của Trường Đại học Công nghệ Đông Á.")
F("Chào hỏi", ["bạn giúp được gì","bạn trả lời được những gì"], "Mình trả lời các câu hỏi về giới thiệu trường, ngành đào tạo, tổ hợp xét tuyển, học phí, hồ sơ, quy chế tuyển sinh và đội ngũ lãnh đạo.")
F("Chào hỏi", ["cảm ơn","cảm ơn bạn nhiều","thanks"], "Rất vui được giúp bạn! Cần hỏi thêm gì cứ nhắn mình nhé.")
F("Chào hỏi", ["tạm biệt","bye bạn"], "Tạm biệt bạn! Chúc bạn một ngày tốt lành và hẹn gặp lại ở EAUT.")

# ---------- Tuyển sinh 2026 ----------
F("Tuyển sinh 2026", ["đối tượng tuyển sinh đại học chính quy","ai được đăng ký xét tuyển vào trường","điều kiện để xét tuyển vào trường"], "Đối tượng: học sinh tốt nghiệp THPT hoặc tương đương. Thí sinh tốt nghiệp ở nước ngoài hoặc là người nước ngoài cần có công nhận văn bằng theo quy định của Bộ Giáo dục và Đào tạo.")
F("Tuyển sinh 2026", ["phạm vi tuyển sinh của trường","trường có tuyển sinh viên ngoài nước không"], "Phạm vi tuyển sinh: trong và ngoài nước.")
F("Tuyển sinh 2026", ["trường có những phương thức xét tuyển nào","năm 2026 trường xét tuyển bằng cách nào","các phương thức tuyển sinh"], "Năm 2026 có 4 phương thức: (1) xét học bạ THPT; (2) xét điểm thi tốt nghiệp THPT; (3) xét kết hợp học bạ và điểm thi tốt nghiệp THPT (không áp dụng khối ngành sức khỏe); (4) xét kết quả thi đánh giá năng lực ĐHQGHN, đánh giá tư duy ĐHBKHN hoặc đánh giá năng lực SPT của ĐHSP Hà Nội.")
F("Tuyển sinh 2026", ["xét tuyển học bạ tính điểm như thế nào","cách tính điểm xét học bạ","xét học bạ lấy điểm mấy học kỳ"], "Phương thức 1 xét học bạ THPT: điểm là trung bình tổng điểm 6 học kỳ, từ kỳ 1 lớp 10 đến kỳ 2 lớp 12.")
F("Tuyển sinh 2026", ["phương thức xét điểm thi tốt nghiệp THPT"], "Phương thức 2 xét tuyển dựa trên kết quả thi tốt nghiệp THPT quốc gia.")
F("Tuyển sinh 2026", ["phương thức xét tuyển kết hợp là gì","xét kết hợp học bạ và điểm thi có áp dụng cho ngành Dược không"], "Phương thức 3 sử dụng kết hợp điểm học bạ và điểm thi tốt nghiệp THPT, không bao gồm khối ngành VI (sức khỏe như Dược học, Điều dưỡng).")
F("Tuyển sinh 2026", ["trường có xét điểm đánh giá năng lực không","xét điểm đánh giá tư duy được không","có xét điểm SPT không"], "Có. Phương thức 4 sử dụng kết quả kỳ thi đánh giá năng lực (ĐHQGHN), đánh giá tư duy (ĐHBKHN) và đánh giá năng lực SPT của Trường ĐHSP Hà Nội.")
F("Tuyển sinh 2026", ["xét tuyển khối H V và năng khiếu như thế nào","ngành nào xét thêm khối H V"], "Các ngành Thiết kế đồ họa số, Kiến trúc, Kiến trúc nội thất xét tuyển thêm khối H, V và sử dụng kết quả các bài thi năng khiếu mà thí sinh đã tham gia.")
F("Học phí & lệ phí", ["học phí năm 2026 là bao nhiêu","học phí của trường","mức học phí dự kiến năm học 2026 – 2027"], "Học phí dự kiến năm học 2026 – 2027: khối kỹ thuật 14.000.000đ – 20.000.000đ/kỳ; khối kinh tế – xã hội 16.000.000đ – 21.500.000đ/kỳ; khối sức khỏe 18.000.000 – 24.000.000đ/kỳ. Nhà trường không thu thêm khoản nào khác nếu không có thông báo chính thức. Hotline: " + HL + ".")
F("Học phí & lệ phí", ["học phí khối kỹ thuật bao nhiêu","học các ngành kỹ thuật tốn bao nhiêu một kỳ"], "Học phí dự kiến khối ngành kỹ thuật năm học 2026 – 2027: 14.000.000đ – 20.000.000đ/kỳ.")
F("Học phí & lệ phí", ["học phí khối kinh tế xã hội bao nhiêu","học ngành kinh tế tốn bao nhiêu một kỳ"], "Học phí dự kiến khối ngành kinh tế – xã hội năm học 2026 – 2027: 16.000.000đ – 21.500.000đ/kỳ.")
F("Học phí & lệ phí", ["học phí khối sức khỏe bao nhiêu","học Dược và Điều dưỡng tốn bao nhiêu một kỳ"], "Học phí dự kiến khối ngành sức khỏe năm học 2026 – 2027: 18.000.000 – 24.000.000đ/kỳ.")
F("Học phí & lệ phí", ["các khoản thu ngoài học phí là gì","ngoài học phí còn phải đóng những khoản nào"], "Các khoản ngoài học phí: hồ sơ và lệ phí xét học bạ 350.000đ; lệ phí nhập học 50.000đ; thẻ thư viện tích hợp thẻ gửi xe 100.000đ; thẻ sinh viên 50.000đ; đồng phục 400.000đ; bảo hiểm y tế, khám sức khỏe, đoàn phí theo quy định; lệ phí thi lại, học lại áp dụng theo từng môn học.")
F("Học phí & lệ phí", ["lệ phí xét tuyển học bạ bao nhiêu","phí nộp hồ sơ xét học bạ"], "Hồ sơ và lệ phí xét tuyển học bạ: 350.000đ/sinh viên.")
F("Học phí & lệ phí", ["lệ phí nhập học bao nhiêu"], "Lệ phí nhập học: 50.000đ/sinh viên.")
F("Học phí & lệ phí", ["thẻ thư viện và thẻ gửi xe giá bao nhiêu"], "Thẻ thư viện tích hợp thẻ gửi xe: 100.000đ/sinh viên.")
F("Học phí & lệ phí", ["thẻ sinh viên giá bao nhiêu"], "Thẻ sinh viên: 50.000đ/sinh viên.")
F("Học phí & lệ phí", ["đồng phục giá bao nhiêu","tiền đồng phục là bao nhiêu"], "Đồng phục: 400.000đ.")
F("Học phí & lệ phí", ["bảo hiểm y tế khám sức khỏe đoàn phí đóng bao nhiêu","phí bảo hiểm y tế bắt buộc"], "Bảo hiểm y tế bắt buộc, khám sức khỏe và đoàn phí thu theo quy định hiện hành.")
F("Học phí & lệ phí", ["thi lại học lại mất bao nhiêu tiền","lệ phí thi lại"], "Lệ phí thi lại, học lại áp dụng cụ thể với từng môn học.")
F("Học phí & lệ phí", ["trường có thu thêm khoản phí nào khác không"], "Ngoài các khoản đã thông báo, nhà trường không thu thêm bất cứ khoản phí nào nếu không có thông báo chính thức đến sinh viên và gia đình.")
F("Hồ sơ nhập học", ["hồ sơ đăng ký xét tuyển gồm những gì","cần chuẩn bị giấy tờ gì để nộp hồ sơ","thủ tục nộp hồ sơ xét tuyển"], "Hồ sơ gồm: phiếu ĐKXT theo mẫu của trường; học bạ THPT (photo công chứng, có thể bổ sung sau); giấy tốt nghiệp tạm thời hoặc bằng tốt nghiệp THPT photo công chứng; giấy khai sinh bản sao; CMND/CCCD photo công chứng; 02 ảnh 4×6 (ghi họ tên, ngày sinh sau ảnh); sổ Đoàn (bổ sung sau); giấy chứng nhận ưu tiên nếu có.")
F("Hồ sơ nhập học", ["học bạ nộp bổ sung sau được không","sổ Đoàn có nộp sau được không"], "Được. Học bạ THPT (bản photo công chứng) và Sổ Đoàn có thể bổ sung sau.")
F("Hồ sơ nhập học", ["nộp ảnh bao nhiêu cái","ảnh hồ sơ cỡ nào"], "Cần 02 ảnh 4×6, ghi rõ họ tên, ngày tháng năm sinh ở mặt sau ảnh.")
F("Liên hệ", ["nộp hồ sơ ở đâu","địa điểm nộp hồ sơ xét tuyển","phòng tuyển sinh ở đâu"], "Phòng Tuyển sinh – Tầng 5, Tòa nhà Polyco, Trường Đại học Công nghệ Đông Á, đường Phan Tây Nhạc, phường Xuân Phương, Hà Nội.")
F("Liên hệ", ["số điện thoại tuyển sinh","hotline tuyển sinh của trường","đường dây nóng tuyển sinh"], f"Đường dây nóng/hotline tuyển sinh: {HL}.")
F("Liên hệ", ["email tuyển sinh của trường","website tuyển sinh"], "Theo thông báo tuyển sinh sau đại học 2023: email tuyensinh@eaut.edu.vn, hotline 082.555.2323, website https://eaut.edu.vn. Bạn nên xác nhận lại với phòng Tuyển sinh để cập nhật.")

# ---------- Sau đại học 2023 ----------
S = "Sau đại học (2023)"
F(S, ["tuyển sinh thạc sĩ có những ngành nào","trường tuyển thạc sĩ ngành gì"], "Thông báo năm 2023 tuyển sinh thạc sĩ chuyên ngành Quản trị kinh doanh (chỉ tiêu 100) và Kế toán (chỉ tiêu 50)." + OLD)
F(S, ["đối tượng dự tuyển thạc sĩ","điều kiện học thạc sĩ là gì"], "Công dân Việt Nam tốt nghiệp đại học ngành phù hợp (hoặc ngành khoa học, kỹ thuật, công nghệ khác sau khi học bổ sung kiến thức), có ngoại ngữ từ Bậc 3, không đang bị kỷ luật cảnh cáo trở lên hay thi hành án hình sự, đủ sức khỏe, nộp hồ sơ và lệ phí đúng hạn." + OLD)
F(S, ["yêu cầu ngoại ngữ học thạc sĩ","thạc sĩ cần chứng chỉ tiếng Anh bậc mấy"], "Cần năng lực ngoại ngữ từ Bậc 3 trở lên theo Khung năng lực ngoại ngữ 6 bậc Việt Nam (hoặc bằng đại học ngành ngoại ngữ, hoặc chương trình học chủ yếu bằng ngoại ngữ)." + OLD)
F(S, ["thời gian đào tạo thạc sĩ","hình thức học thạc sĩ"], "Thời gian đào tạo 24 tháng, hình thức vừa làm vừa học, theo định hướng ứng dụng." + OLD)
F(S, ["học phí thạc sĩ bao nhiêu","học phí toàn khóa thạc sĩ"], "Học phí 75.000.000đ/toàn khóa. Học bổng xét theo quy định hằng năm của Hiệu trưởng." + OLD)
F(S, ["học phí học chuyển đổi thạc sĩ","học bổ sung kiến thức thạc sĩ giá bao nhiêu"], "Học phí học chuyển đổi: 750.000đ/tín chỉ." + OLD)
F(S, ["lệ phí thi tuyển thạc sĩ","phí ôn thi tiếng Anh thạc sĩ","lệ phí nhập học thạc sĩ"], "Lệ phí thi tuyển 1.000.000đ/học viên; lệ phí ôn thi tiếng Anh 800.000đ/tín chỉ; lệ phí nhập học 500.000đ/học viên." + OLD)
F(S, ["phương thức tuyển sinh thạc sĩ","thi thạc sĩ gồm môn gì"], "Kết hợp thi tuyển và xét tuyển: thi 01 môn Tiếng Anh (thi viết) và xét tuyển dựa trên bảng điểm/phụ lục văn bằng đại học." + OLD)
F(S, ["hồ sơ đăng ký thi thạc sĩ gồm những gì"], "Gồm đơn đăng ký dự thi; sơ yếu lý lịch có xác nhận; bản sao chứng thực bằng tốt nghiệp đại học và bảng điểm; chứng chỉ ngoại ngữ còn thời hạn; xác nhận văn bằng của Cục Khảo thí (nếu bằng nước ngoài); 03 ảnh 4×6; giấy khám sức khỏe còn hạn 6 tháng; giấy khai sinh; CCCD/CMND công chứng." + OLD)
F(S, ["thời gian nộp hồ sơ thạc sĩ","hạn đăng ký thi thạc sĩ 2023"], "Đăng ký, nộp hồ sơ và lệ phí từ 20/7/2023 đến 5/9/2023. Giờ tiếp nhận các ngày làm việc: sáng 8h00 – 11h30, chiều 13h30 – 16h30 (trừ chiều thứ 7, Chủ nhật, ngày lễ). Hồ sơ và lệ phí đã nộp không hoàn lại." + OLD)
F(S, ["kế hoạch tuyển sinh thạc sĩ","lịch thi và nhập học thạc sĩ"], "Ôn tập/học chuyển đổi 6/9–31/10/2023; thi tuyển dự kiến 4/11–11/11/2023; công bố kết quả 24/11–30/11/2023; nhập học 2/12–9/12/2023." + OLD)
F(S, ["địa điểm học thạc sĩ","nhận hồ sơ thạc sĩ ở đâu"], "Trụ sở chính: Khu Xuân Ổ A, phường Võ Cường, TP Bắc Ninh, tỉnh Bắc Ninh. Cơ sở đào tạo thực hành: Tòa nhà Polyco, đường Trịnh Văn Bô, quận Nam Từ Liêm, Hà Nội. Điện thoại 0243.555.2008." + OLD)

# ---------- Lãnh đạo ----------
P = [("Đinh Văn Thuận","GS.TS.","Chủ tịch Hội đồng trường",1954,"Công nghệ Nhiệt Lạnh","1978–1995 giảng dạy tại Bách khoa Đà Nẵng; 1995–2015 giảng dạy tại Bách khoa Hà Nội; 2015–2020 Hiệu trưởng Trường ĐH Công nghệ Đông Á; 2020–nay Chủ tịch Hội đồng trường; 1995–2013 Tổng Giám đốc và 2013–nay Chủ tịch HĐQT Tập đoàn POLYCO"),
("Đinh Văn Thành","TS.","Hiệu trưởng",1986,"Tiến sĩ Kỹ thuật Điện – Điện tử (Đại học Southampton, Vương quốc Anh)","2009–2013 Phó TGĐ Tập đoàn POLYCO; 2013–nay TGĐ Tập đoàn POLYCO; 2013–2015 Phó Hiệu trưởng ĐH Công nghệ Vinh; 2015–2020 Phó Hiệu trưởng ĐH Công nghệ Đông Á; 2020–nay Hiệu trưởng"),
("Đinh Văn Nhã","GS.VS.TSKH.NGƯT.","Phó Hiệu trưởng, Chủ tịch Hội đồng Khoa học và Đào tạo, Chủ nhiệm ngành Công nghệ kỹ thuật Điều khiển – Tự động hóa",1948,"Điều khiển tự động hóa","1976–2013 Giảng viên cao cấp, Giám đốc Trung tâm Tự động hóa ĐH Bách khoa Hà Nội; 2013–2015 Phó Hiệu trưởng ĐH Công nghệ Vinh; 2008–nay công tác tại Viện KHCN và Đào tạo Omega; 2015–nay Phó Hiệu trưởng ĐH Công nghệ Đông Á"),
("Đinh Phương Thảo","TS.","Phó Hiệu trưởng",1978,"Quản trị kinh doanh","2009–nay Phó TGĐ Tập đoàn POLYCO; 2017–nay Phó Hiệu trưởng ĐH Công nghệ Đông Á; 2003–nay Giám đốc Công ty CP Đầu tư và Thương mại Thuận Thành; 2008–nay Chủ tịch Công ty CP SAHA"),
("Phan Thị Thu Hường","TS.","Phó Hiệu trưởng, Trưởng phòng Đào tạo",1984,"Tiến sĩ Kỹ thuật Nhiệt (ĐH Bách khoa Hà Nội)","2007–T7/2023 Phó Trưởng bộ môn Kỹ thuật Nhiệt lạnh, ĐH Sư phạm Kỹ thuật Nam Định; T8/2023–T2/2024 Phó trưởng khoa Nhiệt – Điện lạnh, ĐH Công nghệ Đông Á; T2/2024–nay Phó Hiệu trưởng, Trưởng phòng Đào tạo"),
("Thái Thế Hùng","PGS.TS.","Phó Hiệu trưởng, phụ trách nghiên cứu khoa học và khoa Cơ khí",1962,"Tiến sĩ Cơ khí (Université de Savoie, Pháp)","1985–1992 giảng viên ĐH Bách khoa Đà Nẵng; 1992–2001 nghiên cứu sinh tại Pháp; 2002–2021 giảng viên, Trưởng bộ môn Cơ học vật liệu và kết cấu, Viện trưởng Viện Sư phạm kỹ thuật ĐH Bách khoa Hà Nội; 2022–nay Phó Hiệu trưởng ĐH Công nghệ Đông Á"),
("Nguyễn Đức Thắng","PGS.TS.","Phó Hiệu trưởng phụ trách Liên kết học thuật – Hợp tác doanh nghiệp, kiêm Trưởng khoa Du lịch",1980,"Du lịch / Văn hóa","2008–2011 Phó Trưởng khoa QTKD Lữ hành, CĐ Du lịch Hà Nội; 2011–2017 Phó Giám đốc Ban Quản lý Làng Văn hóa – Du lịch các dân tộc Việt Nam; 2017–2022 Trưởng phòng Hành chính Tổng hợp, Bảo tàng Mỹ thuật Việt Nam; 2023–7/2025 Trưởng khoa Du lịch; 8/2025 Phó Hiệu trưởng; Ủy viên Hội đồng Giáo sư liên ngành Văn hóa, Nghệ thuật, TDTT và Du lịch"),
("Ngô Văn Quang","PGS.TS.","Phó Hiệu trưởng phụ trách Khối Kinh tế",1984,"Quản trị kinh doanh (Marketing)","2008–2010 Trung tâm đào tạo Viettel; 2010–2026 giảng viên, Trưởng khoa Trường Kinh tế ĐH Công nghiệp Hà Nội; 04/2026–nay Phó Hiệu trưởng phụ trách Khối Kinh tế")]
for n, t, role, y, maj, hist in P:
    short = n.split()[-1]
    F("Lãnh đạo", [f"{n} là ai", f"thông tin về {t} {n}", f"{n} giữ chức vụ gì", f"thầy cô {short} là ai"], f"{t} {n} – {role}. Sinh năm {y}, chuyên ngành {maj}. Quá trình công tác: {hist}.")
    F("Lãnh đạo", [f"{n} sinh năm bao nhiêu", f"năm sinh của {t} {n}"], f"{t} {n} sinh năm {y}.")
    F("Lãnh đạo", [f"{n} chuyên ngành gì", f"{t} {n} học chuyên ngành nào"], f"Chuyên ngành của {t} {n}: {maj}.")
    F("Lãnh đạo", [f"quá trình công tác của {n}", f"{n} từng làm ở đâu"], f"Quá trình công tác của {t} {n}: {hist}.")
F("Lãnh đạo", ["hiệu trưởng trường là ai","ai là hiệu trưởng hiện nay"], "Hiệu trưởng hiện nay là TS. Đinh Văn Thành (từ 2020).")
F("Lãnh đạo", ["chủ tịch hội đồng trường là ai"], "Chủ tịch Hội đồng trường là GS.TS. Đinh Văn Thuận (từ 2020).")
F("Lãnh đạo", ["ban giám hiệu gồm những ai","trường có mấy phó hiệu trưởng","danh sách phó hiệu trưởng"], "Hiệu trưởng: TS. Đinh Văn Thành. Phó Hiệu trưởng: GS.VS.TSKH.NGƯT. Đinh Văn Nhã; TS. Đinh Phương Thảo; TS. Phan Thị Thu Hường; PGS.TS. Thái Thế Hùng; PGS.TS. Nguyễn Đức Thắng; PGS.TS. Ngô Văn Quang. Chủ tịch Hội đồng trường: GS.TS. Đinh Văn Thuận.")
F("Lãnh đạo", ["ai là trưởng phòng đào tạo","ai phụ trách phòng đào tạo"], "TS. Phan Thị Thu Hường – Phó Hiệu trưởng, Trưởng phòng Đào tạo (từ 02/2024).")
F("Lãnh đạo", ["ai phụ trách nghiên cứu khoa học","ai phụ trách khoa cơ khí"], "PGS.TS. Thái Thế Hùng – Phó Hiệu trưởng, phụ trách nghiên cứu khoa học và khoa Cơ khí.")
F("Lãnh đạo", ["ai phụ trách khối kinh tế","ai phụ trách trường kinh tế"], "PGS.TS. Ngô Văn Quang – Phó Hiệu trưởng phụ trách Khối Kinh tế (từ 04/2026).")
F("Lãnh đạo", ["ai phụ trách khoa du lịch","ai phụ trách hợp tác doanh nghiệp"], "PGS.TS. Nguyễn Đức Thắng – Phó Hiệu trưởng phụ trách Liên kết học thuật – Hợp tác doanh nghiệp, kiêm Trưởng khoa Du lịch.")

# ---------- Quy chế tuyển sinh 2024-2025 ----------
Q = "Quy chế tuyển sinh"
F(Q, ["quy chế tuyển sinh đại học 2024 2025 ban hành khi nào","ai ký quyết định ban hành quy chế tuyển sinh"], "Quy chế Tuyển sinh đại học năm học 2024 – 2025 do Hiệu trưởng TS. Đinh Văn Thành ký ban hành ngày 23/04/2024, có hiệu lực kể từ ngày ký.")
F(Q, ["xử lý nguyện vọng là gì","ngưỡng đầu vào là gì","ngưỡng bảo đảm chất lượng đầu vào là gì"], "Xử lý nguyện vọng là quy trình trên hệ thống tuyển sinh để xác định nguyện vọng cao nhất trong số nguyện vọng thí sinh đủ điều kiện trúng tuyển. Ngưỡng đầu vào (ngưỡng bảo đảm chất lượng) là yêu cầu tối thiểu về năng lực học tập để thí sinh có khả năng theo học và hoàn thành chương trình.")
F(Q, ["xét tuyển thẳng là gì","điểm trúng tuyển là gì","điểm ưu tiên là gì"], "Xét tuyển thẳng là công nhận trúng tuyển với đối tượng theo quy định đã đáp ứng điều kiện dự tuyển nhưng không cần xét ngưỡng đầu vào. Điểm trúng tuyển là ngưỡng điểm mà thí sinh có điểm xét bằng hoặc cao hơn sẽ đủ điều kiện trúng tuyển. Điểm ưu tiên là số điểm chênh lệch giữa mức điểm trúng tuyển của nhóm thí sinh ưu tiên so với mức bình thường.")
F(Q, ["tiêu chí đánh giá và tiêu chí xét tuyển khác nhau thế nào","kỳ thi bổ trợ là gì","thi trực tiếp là gì"], "Tiêu chí đánh giá dùng để phân loại thí sinh theo mức đáp ứng đầu vào; tiêu chí xét tuyển dùng để xác định điều kiện trúng tuyển, thường quy thành điểm xét có tính điểm ưu tiên. Kỳ thi bổ trợ là kỳ thi tổ chức thêm (năng khiếu, tài năng, phỏng vấn) làm một căn cứ xét tuyển. Thi trực tiếp là hình thức có người coi thi trực tiếp (giấy, máy tính hoặc phỏng vấn trước hội đồng).")
F(Q, ["hệ thống hỗ trợ tuyển sinh chung là gì","cổng thông tin tuyển sinh là gì","mã xét tuyển là gì"], "Hệ thống hỗ trợ tuyển sinh chung của Bộ GDĐT là phần mềm hỗ trợ đăng ký nguyện vọng, trao đổi dữ liệu, xử lý nguyện vọng và quản lý dữ liệu trúng tuyển, nhập học. Mã trường và mã xét tuyển là mã số quy ước thống nhất để định danh cơ sở đào tạo và ngành/chương trình cùng phương thức tuyển sinh.")
F(Q, ["yêu cầu chung trong tuyển sinh","trường có trách nhiệm gì trong tuyển sinh"], "Trường thực hiện quyền tự chủ và trách nhiệm giải trình, bảo đảm đúng pháp luật; tạo điều kiện thuận lợi và cơ hội bình đẳng cho mọi thí sinh; phối hợp chặt chẽ với Bộ GDĐT để bảo đảm tính thống nhất, đồng bộ trong hệ thống.")
F(Q, ["nguyên tắc cơ bản trong tuyển sinh","tuyển sinh có công bằng với thí sinh không"], "Nguyên tắc: công bằng với thí sinh (thông tin đầy đủ, cơ hội dự tuyển, đánh giá khách quan, cơ hội trúng tuyển, thực hiện cam kết); bình đẳng giữa các cơ sở đào tạo (hợp tác, cạnh tranh lành mạnh); minh bạch với xã hội (công bố thông tin, trách nhiệm giải trình).")
F(Q, ["ai được đăng ký dự tuyển theo quy chế","đối tượng dự tuyển đại học là ai","thí sinh có bằng trung cấp nghề có được xét tuyển không"], "Đối tượng dự tuyển gồm: người đã tốt nghiệp THPT của Việt Nam hoặc có bằng nước ngoài được công nhận tương đương; người có bằng tốt nghiệp trung cấp ngành nghề thuộc nhóm ngành dự tuyển và đã hoàn thành khối lượng kiến thức văn hóa THPT theo quy định.")
F(Q, ["điều kiện dự tuyển gồm những gì","thí sinh phải đáp ứng điều kiện gì để dự tuyển"], "Thí sinh phải đạt ngưỡng đầu vào theo Điều 9 của Quy chế, đủ sức khỏe học tập theo quy định hiện hành, và có đầy đủ thông tin cá nhân, hồ sơ dự tuyển theo quy định.")
F(Q, ["thí sinh khuyết tật có được đăng ký dự tuyển không"], "Thí sinh khuyết tật bị suy giảm khả năng học tập có nguyện vọng được đăng ký dự tuyển; trường xem xét cho theo học các ngành phù hợp với điều kiện sức khỏe.")
F(Q, ["tổ hợp xét tuyển gồm mấy môn","có phải luôn có môn Toán hoặc Ngữ văn không","một ngành được dùng tối đa bao nhiêu tổ hợp"], "Tổ hợp môn xét tuyển gồm ít nhất 3 môn, trong đó có môn Toán hoặc Ngữ văn. Với xét điểm thi tốt nghiệp THPT, một ngành không dùng quá 4 tổ hợp (trừ trường hợp các tổ hợp chỉ khác nhau ở môn ngoại ngữ).")
F(Q, ["điểm ưu tiên khu vực là bao nhiêu","khu vực 1 được cộng bao nhiêu điểm","khu vực 3 có được cộng điểm không"], "Điểm ưu tiên khu vực: KV1 là 0,75 điểm; KV2-NT là 0,5 điểm; KV2 là 0,25 điểm; KV3 không được cộng điểm.")
F(Q, ["khu vực tuyển sinh được xác định thế nào","khu vực ưu tiên tính theo trường nào"], "Khu vực tuyển sinh xác định theo địa điểm trường mà thí sinh học lâu nhất trong thời gian học THPT (hoặc trung cấp); nếu thời gian học tương đương nhau thì theo trường học sau cùng. Một số trường hợp hưởng ưu tiên theo nơi thường trú (xã khu vực III, vùng dân tộc miền núi, biên giới, hải đảo, học sinh trường phổ thông dân tộc nội trú, quân nhân – công an nghĩa vụ…).")
F(Q, ["ưu tiên khu vực được hưởng trong bao lâu"], "Thí sinh được hưởng chính sách ưu tiên khu vực trong năm tốt nghiệp THPT (hoặc trung cấp) và một năm kế tiếp.")
F(Q, ["điểm ưu tiên đối tượng chính sách là bao nhiêu","đối tượng UT1 UT2 được cộng mấy điểm","thí sinh thuộc nhiều diện ưu tiên được cộng thế nào"], "Nhóm UT1 (đối tượng 01 đến 04) được cộng 2,0 điểm; nhóm UT2 (đối tượng 05 đến 07) được cộng 1,0 điểm. Thí sinh thuộc nhiều diện chỉ được tính một mức ưu tiên cao nhất.")
F(Q, ["công thức tính điểm ưu tiên khi điểm cao","thí sinh trên 22,5 điểm có được cộng đủ điểm ưu tiên không"], "Các mức ưu tiên tương ứng tổng điểm 3 môn theo thang 10 (không nhân hệ số). Thí sinh đạt tổng từ 22,5 điểm trở lên (thang 30) được tính: Điểm ưu tiên = [(30 − tổng điểm đạt được)/7,5] × mức điểm ưu tiên quy định.")
F(Q, ["đối tượng được xét tuyển thẳng","ai được tuyển thẳng vào trường"], "Xét tuyển thẳng gồm: Anh hùng lao động, Anh hùng lực lượng vũ trang nhân dân, Chiến sĩ thi đua toàn quốc; thí sinh đạt giải nhất, nhì, ba kỳ thi chọn học sinh giỏi quốc gia, quốc tế hoặc giải nhất thi khoa học kỹ thuật cấp quốc gia, quốc tế (trong vòng 3 năm). Hiệu trưởng xét thêm các trường hợp: khuyết tật đặc biệt nặng; học sinh có nơi thường trú từ 3 năm, học 3 năm và tốt nghiệp THPT tại huyện nghèo; người nước ngoài đạt yêu cầu tiếng Việt.")
F(Q, ["ngưỡng đầu vào được công bố khi nào","bao giờ trường công bố ngưỡng đầu vào"], "Trường xác định và công bố ngưỡng đầu vào trước thời gian kết thúc đăng ký dự tuyển ít nhất 10 ngày. Với xét điểm thi tốt nghiệp THPT, ngưỡng đầu vào theo quy định chung của Bộ GDĐT.")
F(Q, ["bảo lưu kết quả trúng tuyển trong trường hợp nào","đi nghĩa vụ quân sự có được bảo lưu không"], "Thí sinh có giấy báo trúng tuyển được bảo lưu khi: đi nghĩa vụ quân sự hoặc thanh niên xung phong ngay trong năm trúng tuyển; bị bệnh nặng hoặc tai nạn nghiêm trọng không nhập học đúng hạn (có hồ sơ y tế xác nhận).")
F(Q, ["thời gian bảo lưu tối đa là bao lâu","thủ tục xin bảo lưu kết quả trúng tuyển"], "Thí sinh gửi đơn xin bảo lưu kèm giấy tờ chứng minh trong hạn được gọi nhập học; thời gian bảo lưu tối đa 3 năm. Khi đủ điều kiện học trở lại phải làm thủ tục nhập học và cung cấp minh chứng đã hoàn thành nhiệm vụ hoặc được điều trị phục hồi.")
F(Q, ["đề án tuyển sinh gồm những nội dung gì","trường công bố đề án tuyển sinh khi nào"], "Đề án tuyển sinh có thông tin giới thiệu trường và ngành, chi phí đào tạo và học bổng, kế hoạch – phạm vi – chỉ tiêu – phương thức xét tuyển, thủ tục đăng ký, và phương án xử lý rủi ro. Trường công bố đề án trước khi mở đăng ký dự tuyển đợt đầu ít nhất 30 ngày; điều chỉnh, bổ sung (nếu có) trước ít nhất 15 ngày.")
F(Q, ["đăng ký xét tuyển trên hệ thống như thế nào","đăng ký nguyện vọng ở đâu"], "Thí sinh đăng ký xét tuyển trên cổng thông tin tuyển sinh của Bộ GDĐT và Cổng dịch vụ công quốc gia, theo kế hoạch chung của Bộ. Thời gian đăng ký bắt đầu sau kỳ thi tốt nghiệp THPT và kết thúc sau khi có kết quả thi và xét tốt nghiệp.")
F(Q, ["được đăng ký bao nhiêu nguyện vọng","đỗ nhiều nguyện vọng thì được gọi vào nguyện vọng nào"], "Thí sinh được đăng ký nhiều ngành, nhiều trường, không hạn chế số lượng, nhưng phải xếp thứ tự ưu tiên từ cao xuống thấp (số 1 là cao nhất). Nếu đủ điều kiện trúng tuyển nhiều nguyện vọng, chỉ được công nhận trúng tuyển và gọi nhập học theo nguyện vọng cao nhất.")
F(Q, ["khi đăng ký nguyện vọng cần chọn những thông tin gì"], "Thí sinh chọn: thứ tự ưu tiên nguyện vọng; trường (mã trường); ngành/nhóm ngành/chương trình (mã ngành); phương thức tuyển sinh (mã phương thức); và tổ hợp xét tuyển (mã tổ hợp) đối với phương thức xét theo kết quả thi tốt nghiệp THPT.")
F(Q, ["xét tuyển sớm là gì","trường có xét tuyển sớm không"], "Trường có kế hoạch xét tuyển sớm/xét tuyển kết hợp với một số phương thức; thí sinh đăng ký trực tuyến hoặc trực tiếp tại trường. Thí sinh không bắt buộc xác nhận nhập học sớm; danh sách đủ điều kiện trúng tuyển được tải lên hệ thống để xử lý nguyện vọng cùng các phương thức khác.")
F(Q, ["thí sinh trúng tuyển thẳng có phải nhập học luôn không"], "Không bắt buộc. Thí sinh trúng tuyển thẳng có thể xác nhận nhập học sớm theo thông báo hoặc theo kế hoạch chung; nếu chưa xác nhận nhập học vẫn được đăng ký xét tuyển trên hệ thống chung.")
F(Q, ["nguyên tắc xét tuyển và xử lý nguyện vọng","các thí sinh có được xét bình đẳng không"], "Điểm trúng tuyển xác định theo chỉ tiêu từng ngành nhưng không thấp hơn ngưỡng đầu vào. Với một ngành theo một phương thức và tổ hợp, mọi thí sinh được xét bình đẳng theo điểm xét, không phân biệt thứ tự nguyện vọng. Hệ thống tự động loại bỏ các nguyện vọng thấp của thí sinh đủ điều kiện trúng tuyển nhiều nguyện vọng.")
F(Q, ["tra cứu kết quả xét tuyển ở đâu","khi nào biết điểm trúng tuyển"], "Trường công bố điểm trúng tuyển (và các điều kiện, tiêu chí phụ nếu có) theo từng phương thức và tổ chức cho thí sinh tra cứu kết quả cá nhân trên trang thông tin điện tử của trường (hoặc của nhóm cơ sở phối hợp).")
F(Q, ["giấy báo trúng tuyển gửi như thế nào","xác nhận nhập học thế nào"], "Trường gửi giấy báo trúng tuyển, ghi rõ thủ tục và phương thức nhập học. Thí sinh xác nhận nhập học trực tuyến trên hệ thống trước khi nhập học tại trường.")
F(Q, ["không nhập học đúng hạn thì sao","ốm đau tai nạn không nhập học được có sao không"], "Nếu không có lý do chính đáng, thí sinh bị coi là từ chối nhập học và trường có quyền không tiếp nhận. Nếu ốm đau, tai nạn có xác nhận của bệnh viện quận/huyện trở lên (hoặc thiên tai có xác nhận UBND quận/huyện trở lên), trường xem xét tiếp nhận hoặc bảo lưu kết quả; nếu do sai sót của cán bộ tuyển sinh hoặc thí sinh thì xem xét theo minh chứng.")
F(Q, ["đã nhập học có được xét tuyển nơi khác không"], "Thí sinh đã xác nhận nhập học tại trường không được tham gia xét tuyển ở nơi khác hoặc ở các đợt xét tuyển bổ sung, trừ khi được trường cho phép. Thí sinh nhập học xong được xếp vào lớp cùng ngành/chương trình, cùng năm/đợt/khóa.")
F(Q, ["xét tuyển bổ sung như thế nào","chưa trúng tuyển có xét bổ sung được không"], "Nếu còn chỉ tiêu, hội đồng tuyển sinh quyết định xét tuyển các đợt bổ sung, điều kiện không thấp hơn điều kiện trúng tuyển đợt trước. Thí sinh chưa trúng tuyển hoặc đã trúng tuyển nhưng chưa xác nhận nhập học ở bất cứ đâu có thể đăng ký theo kế hoạch của trường.")
F(Q, ["trách nhiệm của thí sinh khi đăng ký xét tuyển","thí sinh cần lưu ý gì khi đăng ký nguyện vọng"], "Thí sinh phải tìm hiểu kỹ thông tin, không đăng ký ngành/phương thức không đủ điều kiện; cung cấp đầy đủ, chính xác thông tin (cá nhân, khu vực, đối tượng ưu tiên, nguyện vọng, giấy tờ); đồng ý cho trường sử dụng dữ liệu phục vụ xét tuyển; và thanh toán lệ phí trước khi kết thúc đăng ký.")
F(Q, ["trường có trách nhiệm gì với thí sinh","khiếu nại tuyển sinh gửi ở đâu"], "Trường cung cấp đầy đủ, chính xác thông tin lên hệ thống; quy định mức thu lệ phí; tư vấn để thí sinh không đăng ký sai điều kiện; bảo đảm xét tuyển chính xác, công bằng; kiểm tra hồ sơ khi nhập học; và giải quyết đơn phản ánh, khiếu nại, tố cáo theo pháp luật.")
F(Q, ["hội đồng tuyển sinh gồm những ai","ai là chủ tịch hội đồng tuyển sinh"], "Hiệu trưởng quyết định thành lập Hội đồng tuyển sinh: Chủ tịch là Hiệu trưởng; Phó Chủ tịch là Phó Hiệu trưởng phụ trách đào tạo; Ủy viên thường trực là Trưởng hoặc Phó phòng Đào tạo hoặc Khảo thí và Đảm bảo chất lượng; ủy viên gồm các Trưởng phòng, Trưởng khoa/viện, chuyên viên tuyển sinh và chuyên viên CNTT. Người có người thân dự thi hay xét tuyển vào trường không được tham gia HĐTS và các ban giúp việc trong năm đó.")
F(Q, ["nhiệm vụ của hội đồng tuyển sinh","hội đồng tuyển sinh làm những việc gì"], "HĐTS tổ chức tuyển sinh đúng quy chế và pháp luật; thanh tra, kiểm tra nội bộ, giải quyết đơn thư khiếu nại; cập nhật danh sách trúng tuyển và nhập học lên hệ thống chậm nhất 30 ngày sau khi thí sinh hoàn thành thủ tục nhập học; bảo quản tài liệu tuyển sinh; thu và sử dụng lệ phí; tổng kết, khen thưởng, kỷ luật.")
F(Q, ["ban thư ký hội đồng tuyển sinh làm gì"], "Ban Thư ký (Trưởng ban là Ủy viên thường trực HĐTS) công bố thông tin điều kiện, hồ sơ, thời gian, địa điểm đăng ký; kiểm tra hồ sơ thí sinh; cập nhật thông tin lên cổng tuyển sinh của Bộ GDĐT; dự kiến điểm trúng tuyển, gửi giấy báo; lập danh sách trúng tuyển trình HĐTS quyết định.")
F(Q, ["phân chia khu vực tuyển sinh KV1 KV2 KV3","khu vực 1 gồm những nơi nào","khu vực 3 là những quận nào"], "KV1: các xã khu vực I, II, III và các xã có thôn đặc biệt khó khăn vùng dân tộc và miền núi; xã đặc biệt khó khăn vùng bãi ngang ven biển và hải đảo; xã biên giới, xã an toàn khu, xã thuộc Chương trình 135. KV2-NT: các địa phương không thuộc KV1, KV2, KV3. KV2: thị xã, thành phố thuộc tỉnh; thị xã, huyện ngoại thành của thành phố trực thuộc Trung ương (trừ xã thuộc KV1). KV3: các quận nội thành của thành phố trực thuộc Trung ương.")
F(Q, ["đối tượng ưu tiên 01 là ai","đối tượng 02 chính sách ưu tiên là ai","nhóm UT1 gồm đối tượng nào"], "Nhóm UT1 gồm: đối tượng 01 – công dân Việt Nam là người dân tộc thiểu số có nơi thường trú trên 18 tháng trong thời gian học THPT hoặc trung cấp tại Khu vực 1; đối tượng 02 – công nhân trực tiếp sản xuất làm việc liên tục từ 5 năm trở lên, trong đó có ít nhất 2 năm là chiến sĩ thi đua cấp tỉnh trở lên được công nhận và cấp bằng khen. (Đối tượng 03, 04 và nhóm UT2 xem phụ lục đầy đủ của Quy chế.)")

# ---------- Sinh biến thể ----------
PRE = ["","Cho mình hỏi: ","Em muốn hỏi, ","Ad ơi, ","Bạn ơi, ","Xin hỏi: ","Cho em hỏi ","Anh/chị ơi, ","Mình đang thắc mắc ","Tư vấn giúp mình: ","Mình muốn biết ","Chào bạn, ","Hello, ","Cho mình xin thông tin: "]
SUF = [""," ạ?"," với?"," vậy?"," nhỉ?"," nhé?","?"]
def strip(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D"))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
topics = [(cat, t, ans) for cat, ts, ans in FACTS for t in ts]
V = max(1, min(len(PRE) * len(SUF), math.ceil(TARGET * 1.05 / (2 * len(topics)))))
seen, canon, rest = set(), [], []
def add(lst, cat, q, ans):
    k = q.lower().strip()
    if k not in seen:
        seen.add(k); lst.append({"category": cat, "question": q, "answer": ans})
for cat, t, ans in topics:
    cs = [(p, s) for p in PRE for s in SUF if (p, s) != ("", "?")]
    random.shuffle(cs)
    for i, (p, s) in enumerate([("", "?")] + cs[:V - 1]):
        q = (p + t + s); q = q[0].upper() + q[1:]
        lst = canon if i == 0 else rest
        add(lst, cat, q, ans)
        add(lst, cat, strip(q), ans)
random.shuffle(rest)
rows = canon + rest[:max(0, TARGET - len(canon))]
random.shuffle(rows)
with open("seed.jsonl", "w", encoding="utf-8") as f:
    for r in rows: f.write(json.dumps(r, ensure_ascii=False) + "\n")
print(f"Sự kiện (câu trả lời) khác nhau: {len(set(a for _,_,a in topics))} | chủ đề: {len(topics)} | tổng câu hỏi: {len(rows)}")
