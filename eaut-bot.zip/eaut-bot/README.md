# Chatbot tuyển sinh EAUT (chạy offline)

## Cài đặt (làm 1 lần, cần mạng để tải)
1. Cài Ollama: https://ollama.com
2. Tải model:  ollama pull bge-m3   &&   ollama pull qwen2.5:3b
3. pip install -r requirements.txt

## Chạy (không cần mạng)
   uvicorn main:app --host 0.0.0.0 --port 8000
- Chat:    http://localhost:8000          (máy khác trong LAN: http://IP-máy:8000)
- Quản trị: http://localhost:8000/admin   (admin / admin123 -> ĐỔI MẬT KHẨU NGAY)

## Quyền
- Khách: chat tự do. Biên tập viên: thêm/sửa/xóa Q&A, xem câu chưa trả lời.
- Quản trị viên: thêm quyền người dùng + cấu hình giới hạn, ngưỡng, từ khóa chặn.

Sao lưu: copy file data.db.

## Dữ liệu mẫu (~20.000 câu hỏi)
Tắt server, rồi chạy:  python import_seed.py   (cần Ollama chạy + đã pull bge-m3; mất vài phút)
- Dữ liệu sinh từ tài liệu EAUT bằng gen_data.py (sửa/thêm sự kiện trong file này rồi chạy lại: python gen_data.py)
- Các dòng mẫu có danh mục bắt đầu bằng "[mẫu]"; chạy lại import_seed.py sẽ thay thế toàn bộ dòng mẫu cũ.
- Nhớ đổi mật khẩu admin mặc định.
